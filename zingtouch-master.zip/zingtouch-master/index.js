const ZingTouch = require('./dist/zingtouch.min.js').default;
module.exports = ZingTouch;
